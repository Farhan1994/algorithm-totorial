#include <iostream>
#include <fstream>

using namespace std;
ifstream in("input.txt");
ofstream out("output.txt");

class prims
{
private:
    int nodes,edges,graph[100][100],mindist[100],visited[100];
public:
    void input();
    void spanningtree();
    void output();
prims()
{
    edges=nodes=0;
    for(int i=0;i<10;i++)
        {
            visited[i]=mindist[i]=0;
            for(int j=0;j<10;j++)
            {
                graph[i][j]=0;
            }
        }
}
};
void prims::input()
{
    int v1,v2,cost;
    in>>nodes; //# of nodes here
    in>>edges;// edges #
    for(int i=0;i<edges;i++)
    {

        in>>v1;//1st vertex
        in>>v2;//2nd vertex

        in>>cost;//cost of vertex 1 and 2
        graph[v1][v2]=graph[v2][v1]=cost;
    }
}
void prims::spanningtree()
{
    int min=9999,row,col,index=0;
    for(int i=0;i<nodes;i++)
    {
        for(int j=i;j<nodes;j++)
        {
            if(graph[i][j]<min&&graph[i][j]!=0)
            {
                min=graph[i][j];
                row=i;
                col=j;
            }
        }
}


visited[row]=visited[col]=1;
mindist[index++]=min;

    for(int i=0;i<nodes-2;i++)
    {
        min=9999;
        for(int j=0;j<nodes;j++)
        {
            if(visited[j]==1)
            {
                for(int k=0;k<nodes;k++)
                {
                    if(graph[j][k]<min&&graph[j][k]!=0&&visited[k]==0)
                    {
                        min=graph[j][k];
                        row=j;
                        col=k;
                    }
                }
            }
        }
mindist[index++]=min;
visited[row]=1;
visited[col]=1;
}
int total=0;
for(int i=0;i<nodes-1;i++)
{

    total=total+mindist[i];
}
out<<total<<endl;
}
void prims::output()
{
    for(int i=0;i<nodes;i++)
    {

        for(int j=0;j<nodes;j++)
        {
            cout.width(4);

        }
        }
}

int main()
{
prims obj;
obj.input();
obj.output();
obj.spanningtree();
return 0;
}
