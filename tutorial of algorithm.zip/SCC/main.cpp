#include <iostream>
#include <list>
#include <stack>

using namespace std;

class Graph
{
    int V;
    list<int> *adjacent;
    void order(int v,bool visited[],stack<int> &Stack);
    void DFSUtil(int v, bool visited[]);
public:
    Graph(int V);
    void addEdge(int v, int w);
    void printSCCs();
    Graph getTrans();
};

Graph::Graph(int V)
{
    this->V = V;
    adjacent = new list<int>[V];
}


void Graph::DFSUtil(int v, bool visited[])
{

    visited[v] = true;
    cout << v << " ";


    list<int>::iterator i;
    for (i = adjacent[v].begin(); i != adjacent[v].end(); ++i)
        if (!visited[*i])
            DFSUtil(*i, visited);
}

Graph Graph::getTrans()
{
    Graph g(V);
    for (int v = 0; v < V; v++)
    {

        list<int>::iterator i;
        for(i = adjacent[v].begin(); i != adjacent[v].end(); ++i)
        {
            g.adjacent[*i].push_back(v);
        }
    }
    return g;
}

void Graph::addEdge(int v, int w)
{
    adjacent[v].push_back(w);
}

void Graph::order(int v, bool visited[], stack<int> &Stack)
{

    visited[v] = true;

    list<int>::iterator i;
    for(i = adjacent[v].begin(); i != adjacent[v].end(); ++i)
        if(!visited[*i])
            order(*i, visited, Stack);

    Stack.push(v);
}


void Graph::printSCCs()
{
    stack<int> Stack;


    bool *visited = new bool[V];
    for(int i = 0; i < V; i++)
        visited[i] = false;


    for(int i = 0; i < V; i++)
        if(visited[i] == false)
            order(i, visited, Stack);


    Graph gr = getTrans();


    for(int i = 0; i < V; i++)
        visited[i] = false;


    while (Stack.empty() == false)
    {

        int v = Stack.top();
        Stack.pop();

        if (visited[v] == false)
        {
            gr.DFSUtil(v, visited);
            cout << endl;
        }
    }
}

int main()
{

    Graph g(6);
    g.addEdge('a', 'b');
    g.addEdge('a', 'd');
    g.addEdge('a', 'c');
    g.addEdge('b', 'a');
    g.addEdge('b', 'c');
    g.addEdge('d', 'c');

    cout << g.printSCCs();

    return 0;
}
