#include <iostream>
#include <vector>

#include <algorithm>
#include <fstream>



using namespace std;

vector<int> b;
ifstream in("input.txt");
ofstream out("output.txt");


int MCM(int i,int j);

int main()
{
    int c;
    in>>c;
    b=vector<int>(c+1, -1);
    int x;
    for (int i = 1; i <= c; i++) {
        in>>x;
        b[i] =x;
    }
    int n=c-1;
    out<<MCM(1,n);
}

int MCM(int i,int j)
{
    if(i==j)
    {
       return 0;
    }
    int a=INT_MAX;
    for (int q=i;q<j;q++) {
        a=min(a,MCM(i,q)+MCM(q+1,j)+b[i]*b[q+1]*b[j+1]);
    }
    return a;
}
