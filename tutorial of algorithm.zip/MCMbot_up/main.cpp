
#include <iostream>
#include <vector>
#include <fstream>
#include <algorithm>
using namespace std;
vector<int> b;
vector< vector<int> > a;

ifstream in("input.txt");
ofstream out("output.txt");

int main()
{
	int c;
	in>>c;
	int n=c-1;
	b=vector<int>(c+1,-1);
	a=vector<vector<int> > (c,vector<int>(c,0));
	int x;

	for (int i=1;i<=c;i++)
        {
		in>>x;
		b[i]=x;
	}

	for (int q=n;q>0;q--) {
		int p=n-q;
		for (int j=n;j>p; j--) {
			int i=j-p-1;
			a[i][j]=INT_MAX;
			for (int r=i;r<j;r++) {
				a[i][j] =min(a[i][j],a[i][r]+a[r+1][j]+b[i]*b[r+1]*b[j+1]);
			}
		}
	}
	out<<a[1][n];
}
