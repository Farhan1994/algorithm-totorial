#include<iostream>
#include<fstream>

#define INFINITY 9999 //if infinity input 9999

using namespace std;
ifstream in("input.txt");
ofstream out("output.txt");

class Dijkstra{
    private:
        int adjMat[100][100];
        int predecessor[100],dist[100];
        bool mark[100];
        int source;
        int nodes;
    public:
        void read();
        void init();
        int getClosestUnmarkedNode();
        void calculateDistance();
        void output();
        void printPath(int);
};

void Dijkstra::read(){

    in>>nodes; //number of nodes+should be greater than 0
    for(int i=0;i<nodes;i++) {
        for(int j=0;j<nodes;j++) {
            in>>adjMat[i][j]; //enter the positive weights
        }
    }
    in>>source; //source should be between 0 to node-1
}


void Dijkstra::init(){
    for(int i=0;i<nodes;i++) {
        mark[i] = false;
        predecessor[i] = -1;
        dist[i] = INFINITY;
    }
    dist[source]= 0;
}


int Dijkstra::getClosestUnmarkedNode(){
    int minDistance = INFINITY;
    int closestUnmarkedNode;
    for(int i=0;i<nodes;i++) {
        if((!mark[i]) && ( minDistance >= dist[i])) {
            minDistance = dist[i];
            closestUnmarkedNode = i;
        }
    }
    return closestUnmarkedNode;
}


void Dijkstra::calculateDistance(){
    init();
    int minDistance = INFINITY;
    int closestUnmarkedNode;
    int count=0;
    while(count<nodes) {
        closestUnmarkedNode = getClosestUnmarkedNode();
        mark[closestUnmarkedNode] = true;
        for(int i=0;i<nodes;i++) {
            if((!mark[i]) && (adjMat[closestUnmarkedNode][i]>0) ) {
                if(dist[i] > dist[closestUnmarkedNode]+adjMat[closestUnmarkedNode][i]) {
                    dist[i] = dist[closestUnmarkedNode]+adjMat[closestUnmarkedNode][i];
                    predecessor[i] = closestUnmarkedNode;
                }
            }
        }
        count++;
    }
}


void Dijkstra::printPath(int node){
    if(node == source)
        out<<(char)(node + 97)<<"..";
    else if(predecessor[node] == -1)
        out<<(char)(node + 97)<<endl;
    else {
        printPath(predecessor[node]);
        out<<(char) (node + 97)<<"..";
    }
}


void Dijkstra::output(){
    for(int i=0;i<nodes;i++) {
        if(i == source)
            out<<(char)(source + 97)<<source;
        else
            printPath(i);
        out<<","<<dist[i]<<endl;
    }
}

int main(){
    Dijkstra G;
    G.read();
    G.calculateDistance();
    G.output();
    return 0;
}
