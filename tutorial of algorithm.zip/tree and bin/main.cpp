#include<stdio.h>
#include<iostream>
#include<string.h>
#include<fstream>
#include<stdlib.h>
using namespace std;


#define MAX 10000

ifstream in("input.txt");
ifstream inW("output.txt");
ofstream out("output.txt"); //saving frequency here
ofstream output("outputBin.txt"); //saving binary value here
struct link
{
    int freq;
    char ch[MAX];
    struct link* right;
    struct link* left;
};
typedef struct link node;
node* create(char a[], int x)
{
    node* ptr;
    ptr = (node *) malloc(sizeof(node));
    ptr->freq = x;
    strcpy( ptr->ch , a);
    ptr->right = ptr->left = NULL;
    return(ptr);

}
void sort(node* a[], int n)
{
    int i, j;
    node* temp;
    for (i = 0; i < n - 1; i++)
        for (j = i; j < n; j++)
            if (a[i]->freq > a[j]->freq)
                {
                    temp = a[i];
                    a[i] = a[j];
                    a[j] = temp;
                }
}
void sright(node* a[], int n)
{
    int i;
    for (i = 1; i < n - 1; i++)
        a[i] = a[i + 1];
}

void Assign_Code(node* tree, int c[], int n)
{
            int i;
            if ((tree->left == NULL) && (tree->right == NULL))
            {
               for (i = 0; i < n; i++)
                {
                    output<<c[i];
                }
            }
            else
            {
                c[n] = 1;
                n++;
                Assign_Code(tree->left, c, n);
                c[n - 1] = 0;
                Assign_Code(tree->right, c, n);
            }

}
void Delete_Tree(node * root)
{
    if(root!=NULL)
    {
        Delete_Tree(root->left);
        Delete_Tree(root->right);
            free(root);
    }

}
int main()
{
            int freqn[128];
            char ch;
            if(!in)
            {
                cout<<"No file"<<endl;
                return 1;
            }
            for(int i=0;i<128;i++)
            {
                freqn[i]=0;
            }
            ch=in.get();
            while(ch!=EOF)
    {
        ch=toupper(ch);
        freqn[ch]++;
        ch=in.get();
    }
    for(char ch='A';ch<='Z';ch++)
    {
       if(freqn[ch]>0){
            out<<ch<<freqn[ch]<<endl;
        }

    }
    int words=0;
    string word;
    while(inW>>word)
    {
        words++;
    }

            node* ptr, * head;
            int i,  total = 0, u, c[15];
            char str[MAX];
            node* a[12];
            int freq;

            for (i = 0; i < words; i++)
            {
                inW>>str>>freq;
                a[i] = create(str, freq);
            }
            while (words > 1)
            {
                 sort(a, words);
                 u = a[0]->freq + a[1]->freq;
                 strcpy(str,a[0]->ch);
                 strcat(str,a[1]->ch);
                  ptr = create(str, u);
                  ptr->right = a[1];
                  ptr->left = a[0];
                  a[0] = ptr;
                  sright(a, words);
                  words--;
            }
            Assign_Code(a[0], c, 0);
            Delete_Tree(a[0]);
}

