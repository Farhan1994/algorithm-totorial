#include<iostream>
#include<queue>
#include<vector>
#include<fstream>


using namespace std;

ifstream in("input.txt");
ofstream out("output.txt");

int main()
{
int x;
char a,b,source;
vector<int>y[500];
	in>>x>>source;//number of edges input1, source input2

	for(int i=0;i<x;i++){
		in>>a>>b;
		y[a].push_back(b);
		y[b].push_back(a);
	}
queue<int> q;
bool visited[500];
for(int i=0;i<500;i++)
visited[i]=false;
q.push(source);

visited[source]=true;

while(!q.empty())
{
		int front = q.front();
		out<<(char)front<<"->";
		q.pop();
	for(vector<int>::iterator it=y[front].begin();
		it!=y[front].end();++it)
		{
			if(visited[*it]==false)
			{
				visited[*it]=true;
				q.push(*it);
			}
		}
}


	return 0;
}
